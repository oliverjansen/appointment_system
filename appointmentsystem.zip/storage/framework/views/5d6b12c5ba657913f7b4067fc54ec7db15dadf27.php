<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
        
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
         
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/customize.css')); ?>" >
        <title>Document</title>
    <style>
    /* CUSTOM WIDTHS */
.h-10, .h-xs-10 { height: 10%!important; }
.h-15, .h-xs-15 { height: 15%!important; }
.h-20, .h-xs-20 { height: 20%!important; }

/* BREAKPOINTS */

@media (min-height: 376px) {
    /* CUSTOM WIDTHS */
    .h-sms-100 { height: 100%!important; }
    .h-sms-90 { height: 90%!important; }
    .h-sms-70 { height: 70%!important; }
}


/* SM breakpoint */
@media (min-height: 576px) {
    /* CUSTOM WIDTHS */
    .h-sm-100 { height: 100%!important; }
    .h-sm-90 { height: 90%!important; }
    .h-sm-70 { height: 70%!important; }
}

/* MD breakpoint*/
@media (min-height: 768px) {    
    /* CUSTOM WIDTHS */
    .h-md-100 { height: 100%!important; }
    .h-md-85 { height: 85%!important; }
    .h-md-70 { height: 70%!important; }
}

/* LG breakpoint */
@media (min-height: 992px) {
    /* CUSTOM WIDTHS */
    .h-lg-100 { height: 100%!important; }
    .h-lg-90 { height: 90%!important; }
    .h-lg-70 { height: 70%!important; }
}

    </style>
    </head>
    <body>
        <div class="container-fluid text-center  pt-5  pb-3 p-lg-5 mt-4 mb-4 ">
            <h3 class="fw-bolder bg-dark text-light p-4 bg-opacity-10" >ANALYTICS</h3>
        </div>
    
        <div class="container-fluid mb-5 bg-semi-white" >
            <div>
                <?php if(session('success')): ?>
                   <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                   </div>
                <?php elseif(session('danger')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo e(session('danger')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
               </div>
                <?php endif; ?>
            </div>
            
                <div class="container-fluid">
                    <div class="card shadow-sm mb-5 col-12 p-0 col-lg-10  mx-auto" style="" >
                        <div class=" card-header text-center  font-weight-bold 
                        bg-semi-grey ">
                        Services Analytic
                        </div>
                        <div class="row p-5">
                            <div class="col col-6 col-md-4 col-sm-6 h-50">
                                <div class="card text-white bg-primary mb-3 h-lg-90 h-sm-90 h-sms-90" style="">
                                    <div class="card-header text-center">Total number of available slot for vaccine (Consumable)</div>
                                    <div class="card-body">
                                    <h5 class="card-title text-center"><?php echo e($total_vaccine_slot); ?></h5>
                                
                                    </div>
                                </div>
                            </div>

                            <div class="col col-6 col-md-4 col-sm-6">

                                <div class="card text-white bg-secondary mb-3  h-lg-90 h-sm-90 h-sms-90" style="">
                                    <div class="card-header text-center">Total number of available slot Covid Vaccine (Consumable)</div>
                                    <div class="card-body">
                                    <h5 class="card-title text-center"><?php echo e($total_available_slot_codiv_vaccine); ?></h5>
                                
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col col-6 col-md-4 col-sm-6">

                                <div class="card text-white bg-secondary mb-3 h-lg-90 h-sm-90 h-sms-90" style="">
                                    <div class="card-header text-center">Total number of available slot for medicine (Consumable)</div>
                                    <div class="card-body">
                                    <h5 class="card-title text-center"><?php echo e($total_available_slot_medicine); ?></h5>
                                
                                    </div>
                                </div>
                            </div>
                            <div class="col col-6 col-md-4 col-sm-6">
                                <div class="card text-white bg-success mb-3 h-lg-90 h-sm-90 h-sms-90" style="">
                                    <div class="card-header text-center">Total number of slot for checkup</div>
                                    <div class="card-body">
                                    <h5 class="card-title text-center"><?php echo e($total_slot_checkup); ?></h5>
                                    
                                    </div>
                                </div>
                            </div>
                            <div class="col col-6 col-md-4 col-sm-6">

                                <div class="card text-white bg-secondary mb-3 h-lg-90 h-sm-90 h-sms-90" style="">
                                    <div class="card-header text-center">Total number of distributed medicines</div>
                                    <div class="card-body">
                                    <h5 class="card-title text-center"><?php echo e($total_distributed_medicine); ?></h5>
                                
                                    </div>
                                </div>
                            </div>
                            <div class="col col-6 col-md-4 col-sm-6">
                                <div class="card text-white bg-primary mb-3 h-lg-90 h-sm-90 h-sms-90" style="">
                                    <div class="card-header text-center">Total number of covid vaccinated residents</div>
                                    <div class="card-body">
                                    <h5 class="card-title text-center"><?php echo e($total_covid_vaccinated_residents); ?></h5>
                                    
                                    </div>
                                </div>
                            </div>
                            

                        </div> 
                    </div> 
                 </div>
                <div class="container-fluid overflow-hidden">
                    <div class="row justify-content-center"> 
                        <div class="card shadow-sm mb-5 col-12 col-lg-5 h-lg-90 h-sm-90 h-sms-90 " style="">
                            <div class=" card-header text-center p-3 font-weight-bold 
                            bg-semi-grey">
                              Number of Slot per Service
                            </div>
                            <div class="card-body">
                                <div class="panel panel-default">
                                    <div class="panel-heading"></div>
                                    <div class="panel-body">
                                        <canvas id="Number_slot_perservice" height="400" width="600" class="w-100 h-100"></canvas>
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                        <div class="card shadow-sm mb-5 ml-3 col-12 col-lg-5 offset" style="" >
                            <div class=" card-header text-center p-3 font-weight-bold 
                            bg-semi-grey">
                              Number of Slot Covid Dose
                            </div>
                            <div class="card-body">
                                <div class="panel panel-default">
                                    <div class="panel-heading"></div>
                                    <div class="panel-body">
                                        <canvas id="vaccine_slot_dose" height="400" width="700" class="w-100 h-100"></canvas>
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                        <div class="card shadow-sm mb-5 ml-3 col-12 h-100 w-100 col-lg-5 col-md-5 offset" >
                            <div class=" card-header text-center p-3 font-weight-bold 
                            bg-semi-grey">
                              Covid Vaccinated and Unvaccinated <br>
                              (Registered Resident)
                            </div>
                            <div class="card-body">
                                <div class="panel panel-default">
                                    <div class="panel-heading"></div>
                                    <div class="panel-body">
                                        <canvas id="vaccinated_unvaccinated_covid"  class="w-100 h-100"></canvas>
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card shadow-sm mb-5 col-lg-10 mx-auto p-0" style="" >
                    <div class=" card-header text-center p-3 font-weight-bold 
                    bg-semi-grey">
                    Appointment Analytic
                    </div>
                    <div class="row p-5">
                        <div class="col col-6 col-md-4 col-sm-6">
                            <div class="card text-white bg-success mb-3 h-lg-90 h-sm-90 h-sms-90" style="">
                                <div class="card-header text-center">Total number of successfull appointments</div>
                                <div class="card-body">
                                <h5 class="card-title text-center"><?php echo e($total_appointment_success); ?></h5>
                               
                                </div>
                            </div>
                        </div>
                        <div class="col col-6 col-md-4 col-sm-6">

                            <div class="card text-white bg-danger mb-3 h-lg-90 h-sm-90 h-sms-90" style="">
                                <div class="card-header text-center">Total number of Expired appointments</div>
                                <div class="card-body">
                                <h5 class="card-title text-center"><?php echo e($total_appointment_expired); ?></h5>
                               
                                </div>
                            </div>
                        </div>
                        <div class="col col-6 col-md-4 col-sm-6">

                            <div class="card text-white bg-danger mb-3 h-lg-90 h-sm-90 h-sms-90" style="">
                                <div class="card-header text-center">Total number of Canceled appointments</div>
                                <div class="card-body">
                                <h5 class="card-title text-center"><?php echo e($total_appointment_canceled); ?></h5>
                                
                                </div>
                            </div>
                        </div>
                
                    </div>
                </div>
                <div class="container-fluid overflow-hidden " style="text-align:center">
                    <div class="row justify-content-center"> 
                        <div class="card shadow-sm mb-5 col-12 col-lg-5 h-lg-90 h-sm-90 h-sms-90" style="">
                            <div class=" card-header text-center p-3 font-weight-bold 
                            bg-semi-grey">
                              Appointments Per Months
                            </div>
                            <div class="card-body" style="text-align:center">
                                <div class="panel panel-default " style="text-align:center">
                                    <div class="panel-heading" ></div>
                                    <div class="panel-body" style="text-align:center">
                                        <canvas id="appointments_permonths" height="900" width="900" class="w-100 h-100"></canvas>
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                        <div class="card shadow-sm mb-5 ml-3 col-12 col-lg-5 offset" style="width: 100%" >
                            <div class=" card-header text-center p-3 font-weight-bold 
                            bg-semi-grey">
                             Most Frequent Service Appointmented
                            </div>
                            <div class="card-body">
                                <div class="panel panel-default">
                                    <div class="panel-heading"></div>
                                    <div class="panel-body" style="text-align:center">
                                        <canvas id="mostfrequent" height="900" width="900" class="w-100 h-100"></canvas>
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                        <div class="card shadow-sm mb-5 ml-3 col-12 col-lg-5 offset" style="width: 100%" >
                            <div class=" card-header text-center p-3 font-weight-bold 
                            bg-semi-grey">
                             Number of Appointments Base on Status
                            </div>
                            <div class="card-body">
                                <div class="panel panel-default">
                                    <div class="panel-heading"></div>
                                    <div class="panel-body">
                                        <canvas id="appointment_status" height="900" width="900" class="w-100 h-100"></canvas>
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card shadow-sm mb-5 col-lg-10 mx-auto" style="" >
                    <div class=" card-header text-center p-3 font-weight-bold 
                    bg-semi-grey">
                    Residents Analytic
                    </div>
                    <div class="row p-5">
                        <div class="col col-6 col-md-4 col-sm-6">

                            <div class="card text-white bg-primary mb-3 h-lg-90 h-sm-90 h-sms-90" style="">
                                <div class="card-header text-center ">Number Registered Residents</div>
                                <div class="card-body">
                                <h5 class="card-title text-center"><?php echo e($pie_user_approved1); ?> </h5>
                               
                                </div>
                            </div>
                        </div>
                        <div class="col col-6 col-md-4 col-sm-6">

                            <div class="card text-white bg-secondary mb-3 h-lg-90 h-sm-90 h-sms-90" style="">
                                <div class="card-header text-center">Number of Pending Registration of Residents</div>
                                <div class="card-body">
                                <h5 class="card-title text-center"><?php echo e($pie_user_pending1); ?></h5>
                            
                                </div>
                            </div>
                        </div>
                        <div class="col col-6 col-md-4 col-sm-6">
                            <div class="card text-white bg-success mb-3 h-lg-90 h-sm-90 h-sms-90" style="">
                                <div class="card-header text-center">Number of Rejected Registration of Residents</div>
                                <div class="card-body">
                                <h5 class="card-title text-center"><?php echo e($pie_user_rejected1); ?></h5>
                               
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container-fluid overflow-hidden">
                    <div class="row justify-content-center"> 
                        <div class="card shadow-sm mb-5 col-12 col-lg-5" style="" >
                            <div class=" card-header text-center p-3 font-weight-bold 
                            bg-semi-grey">
                              Number of Registration Base on Status (%)
                            </div>
                            <div class="card-body">
                                <div class="panel panel-default">
                                    <div class="panel-heading"></div>
                                    <div class="panel-body" style="text-align:center">
                                        <canvas id="pieUser" height="400" width="600" class="w-100 h-100"></canvas>
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                        <div class="card shadow-sm mb-5 ml-3 col-12 col-lg-5 offset" style="width: 100%" >
                            <div class=" card-header text-center p-3 font-weight-bold 
                            bg-semi-grey">
                             Number of Resident Registration
                            </div>
                            <div class="card-body">
                                <div class="panel panel-default">
                                    <div class="panel-heading"></div>
                                    <div class="panel-body " style="text-align:center">
                                        <canvas id="registered_user_line_chart" height="900" width="900" class="w-100 h-100"></canvas>
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                    </div>
                </div>
             

            </div>  
        
            
          
        </div>
    
    
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> 
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    
    </body>
    </html>
    
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.0.1/dist/chart.umd.min.js"></script>
    
        <script>
    //         var year = <?php echo $year; ?>;
    //         var user = <?php echo $user; ?>;
    //         var barChartData = {
    //             labels: year,
    //             datasets: [{
    //                 label: 'User',
    //                 backgroundColor: "blue",
    //                 data: user
    //             }]
    //         };
        
    // window.onload = function() {
    //     var ctx = document.getElementById("canvas").getContext("2d");

    //     window.myBar = new Chart(ctx, {
    //         type: 'bar',
    //         data: barChartData,
    //         options: {
    //             elements: {
    //                 rectangle: {
    //                     borderWidth: 2,
    //                     borderColor: '#c1c1c1',
    //                     borderSkipped: 'bottom'
    //                 }
    //             },
    //             responsive: true,
    //             title: {
    //                 display: true,
    //                 text: 'Yearly User Joined'
    //             }
    //         }
    //     });

        
    // };

    //   var year = <?php echo $year; ?>;
    //   var user = <?php echo $user; ?>;
  
    //   const data = {
    //     labels: year,
    //     datasets: [{
    //       label: 'User',
    //       backgroundColor: 'rgb(255, 99, 132)',
    //       borderColor: 'rgb(255, 99, 132)',
    //       data: user,
    //     }]
    //   };
  
    //   const config = {
    //     type: 'line',
    //     data: data,
    //     options: {}
    //   };
  
    //   const myChart = new Chart(
    //     document.getElementById('myChart'),
    //     config
    //   );


// Registered user per month line Monthly =================================================

      var user_line_labels =  <?php echo e(Js::from($user_line_labels)); ?>;
    var user_line_data =  <?php echo e(Js::from($user_line_data)); ?>;
  
    const data_user = {
        labels: user_line_labels,
        datasets: [{
            label: 'Residents',
            backgroundColor: 'rgb(255, 99, 132)',
            borderColor: 'rgb(255, 99, 132)',
            data: user_line_data,
        }]
    };
  
    const config_user = {
        type: 'line',
        data: data_user,
        options: {}
    };
  
    const myChart = new Chart(
        document.getElementById('registered_user_line_chart'),
        config_user
    );
// pei chart user ================================================= 



const user_pie = {
  labels: [
    'Pending Registration (%)',
    'Approved Registration (%)',
    'Rejected Registration (%)'
  ],
  datasets: [{
    label: [],
    data: [<?php echo e($pie_user_pending); ?>, <?php echo e($pie_user_approved); ?>, <?php echo e($pie_user_rejected); ?>],
    backgroundColor: [
      'rgb(255, 99, 132)',
      'rgb(54, 162, 235)',
      'rgb(255, 205, 86)'
    ],
    hoverOffset: 4
  }]
};

const config_user_pie= {
  type: 'doughnut',
  data: user_pie,
};

const pie_user = new Chart(
    document.getElementById('pieUser'),
    config_user_pie
);

// pei chart slot per service ================================================= 

const number_perservice_pie = {
  labels: [
    'Slot Vaccine',
    'Slot Medicine ',
    'Slot Checkup'
  ],
  datasets: [{
    label: ["Service"],
    data: [<?php echo e($pie_slot_service); ?>, <?php echo e($pie_slot_medicine); ?>, <?php echo e($pie_slot_checkup); ?>],
    backgroundColor: [
      'rgb(255, 99, 132)',
      'rgb(54, 162, 235)',
      'rgb(255, 205, 86)'
    ],
    hoverOffset: 4
  }]
};

const config_slot_pie= {
  type: 'bar',
  data: number_perservice_pie,
};

const pie_slot = new Chart(
    document.getElementById('Number_slot_perservice'),
    config_slot_pie
);

// vaccine_slot_dose ========================================================

const number_slot_covid_pie = {
  labels: [
    'Slot 1st dose',
    'Slot 2nd Dose ',
    'Slot Booster'
  ],
  datasets: [{
    label: ["Covid Vaccnine"],
    data: [<?php echo e($vaccine_slot_dose1); ?>, <?php echo e($vaccine_slot_dose2); ?>, <?php echo e($vaccine_slot_dose3); ?>],
    backgroundColor: [
      'rgb(255, 99, 132)',
      'rgb(54, 162, 235)',
      'rgb(255, 205, 86)'
    ],
    hoverOffset: 4
  }]
};

const config_coid_slot_pie= {
  type: 'bar',
  data: number_slot_covid_pie,
};

const pie_covid_slot = new Chart(
    document.getElementById('vaccine_slot_dose'),
    config_coid_slot_pie
);

// Vaccinated and not vaccinated ========================================================
const number_vaccinated_covid_pie = {
  labels: [
    'Vaccinated (%)',
    'Unvaccinated (%)',
  ],
  datasets: [{
    label: [""],
    data: [<?php echo e($vaccincate_covid_user); ?>, <?php echo e($unVaccinated_covid_user); ?>],
    backgroundColor: [
      'rgb(255, 99, 132)',
      'rgb(54, 162, 235)',
      'rgb(255, 205, 86)'
    ],
    hoverOffset: 4
  }]
};

const config_covid_vaccinated_pie= {
  type: 'pie',
  data: number_vaccinated_covid_pie,
};

const pie_covid_vaccinated_unvaccinated = new Chart(
    document.getElementById('vaccinated_unvaccinated_covid'),
    config_covid_vaccinated_pie
);

// appointments permonths ===========================================

var appointment_permonth_line_labels =  <?php echo e(Js::from($appointment_permonth_line_labels)); ?>;
    var appointment_permonth_line_data =  <?php echo e(Js::from($appointment_permonth_line_data)); ?>;
  
    const data_appointments_permonths = {
        labels: appointment_permonth_line_labels,
        datasets: [{
            label: 'Appointments',
            backgroundColor: [     
                'rgb(255, 99, 132)',
                'rgb(54, 162, 235)',
                'rgb(255, 205, 86)'],
            borderColor: 'rgb(255, 99, 132)',
            data: appointment_permonth_line_data,
        }]
    };
  
    const config_most_frequent_service = {
        type: 'line',
        data: data_appointments_permonths,
        options: {}
    };
  
    const most_frequent_serive = new Chart(
        document.getElementById('appointments_permonths'),
        config_most_frequent_service
    );

// mostfrequent ===========================================

var appointment_most_frequent_labels =  <?php echo e(Js::from($appointment_most_frequent_labels)); ?>;
    var appointment_most_frequent_data =  <?php echo e(Js::from($appointment_most_frequent_data)); ?>;
  
    const data_most_frequent_serive = {
        labels: appointment_most_frequent_labels,
        datasets: [{
            label: 'Frequent Sevice',
            backgroundColor: [     
                'rgb(255, 99, 132)',
                'rgb(54, 162, 235)',
                'rgb(255, 205, 86)'],
            borderColor: [     
                'rgb(255, 99, 132)',
                'rgb(54, 162, 235)',
                'rgb(255, 205, 86)'],
            data: appointment_most_frequent_data,
        }]
    };
  
    const config_appontment_permonth = {
        type: 'bar',
        data: data_most_frequent_serive,
        options: {}
    };
  
    const appointment_permonth = new Chart(
        document.getElementById('mostfrequent'),
        config_appontment_permonth
    );

    //appointment_status ==============================

    
    var appointment_status_labels =  <?php echo e(Js::from($appointment_status_labels)); ?>;
    var appointment_status_data =  <?php echo e(Js::from($appointment_status_data)); ?>;
  
    const data_appontment_status= {
        labels: appointment_status_labels,
        datasets: [{
            backgroundColor: [     
                'rgb(255, 99, 132)',
                'rgb(54, 162, 235)',
                'rgb(255, 205, 86)'],
            borderColor: [     
                'rgb(255, 99, 132)',
                'rgb(54, 162, 235)',
                'rgb(255, 205, 86)'],
            data: appointment_status_data,
        }]
    };
  
    const config_appointment_status = {
        type: 'bar',
        data: data_appontment_status,
        options: {
            plugins:{
                legend:{
                    display: false
                }
            }
        }
    };
  
    const appointment_status = new Chart(
        document.getElementById('appointment_status'),
        config_appointment_status
    );

        </script>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\AppointmentSystem\resources\views/analytic.blade.php ENDPATH**/ ?>