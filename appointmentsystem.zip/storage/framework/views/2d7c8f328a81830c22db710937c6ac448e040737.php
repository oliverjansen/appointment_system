<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
   <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.js"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/customize.css')); ?>" >
    
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap4.min.css">
    <title>Document</title>


    <style>




    </style>
</head>
<body>
  
  <!-- modal recheck dup-->

  <div class="modal fade" id="recheckup_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Follow-Up Checkup</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-body">

        <form action=" <?php echo e(route('update_checkup')); ?> " method="POST" class="m-2">
            <?php echo csrf_field(); ?>
            <?php echo e(csrf_field()); ?>

            <input type="text" id="user_id" name="user_id" hidden>


        <div class="form-group" id="require_checkup" name="require_checkup">
            <label for="service" class="col-form-label">Required</label>
                <div class="form-check ">
                    <input class="form-check-input" type="radio" name="require"  value="yes">
                    <label class="form-check-label" for="Yes" >
                    Yes
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="require" value="no">
                    <label class="form-check-label" for="No" >
                    No
                    </label>
              </div>    
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-danger btn-sm w-25">Save</button>
            <button type="button" class="btn btn-primary btn-sm w-25" data-dismiss="modal">cancel</button>
            
        </div>
        </form>
    </div>
   
    </div>
    </div>
</div>



<!-- Modal -->
<div class="modal fade" id="view_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header mb-2 mt-4" >
        <p class="text-center">
          <h5>
           <small class="font-weight-light ">IDENTIFICATION CARD</small>
          </h5>
         
          
        </p>
      </div>
      <div class="modal-body">
        <div class="container">
         
          <div class="row">
            <input type="text" id="image_id" name="image_id" hidden>
            
            <img id="view_image" src="" alt=".." class="w-100 h-75" >
            
          </div>
          <div class="row d-flex justify-content-center mt-4 mb-2">
            <div class="text-center">
              <div class="row">
                ID type:<p id="id_type" class="text-center ml-2 font-weight-bold text-lowercase h5"></p></p>
              </div>
    

            </div>
          </div>
          
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
  <!-- modal delete-->
  <div class="modal fade" id="delete_appointment_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">

        <form action="<?php echo e(route ('delete_appointment_admin')); ?>  " method="POST">
            <?php echo csrf_field(); ?>
              
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel"></h5>
              <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <input type="text"  id="delete_id" name="delete_id" hidden>
              Are you sure you want to delete this Appointment?
            </div>
            <div class="modal-footer">
            
              <button type="submit" class="btn btn-danger btn-sm w-25">Yes</button>
              <button type="button" class="btn btn-primary btn-sm w-25" data-dismiss="modal">No</button>
            </div>
         </form>

      </div>
    </div>
  </div>
<!-- reject modal -->

  <div class="modal fade" id="cancel_appointment_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">

        <form action="<?php echo e(route ('canceled_appointment')); ?> " method="POST">
            <?php echo csrf_field(); ?>
            <?php echo e(csrf_field()); ?>

        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"></h5>
          <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <input type="text"  id="calcel_id" name="calcel_id" hidden>
          <input type="text"  id="user_id" name="user_id" hidden>

          <input type="text"  id="user_phoneNo" name="user_phoneNo" hidden>
          <input type="text"  id="message" name="message" hidden>
          <input type="text"  id="service" name="service" hidden>


          <div class="form-group">
            <label for="service" class="col-form-label">Message</label>
            <select name="message_select" id="message_select" class ="mb-3 block mt-1 w-full border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm">
                  <option value="default_message" selected>Cancel Appointment</option>
                  <option value="add_message">Customize Message  </option>
          </select>
            <textarea name="cancel_message" id="cancel_message" cols="30" rows="5" class="block mt-1 w-full border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm">

            </textarea>
        </div>
          
        </div>
        <div class="modal-footer">
         
          <button type="submit" class="btn btn-danger reject_btn btn-sm w-25">Yes</button>
          <button type="button" class="btn btn-primary btn-sm w-25" data-dismiss="modal">No</button>
        </div>
         </form>

      </div>
    </div>
  </div>
  <!-- reschedule modal -->

  <div class="modal fade" id="reschedule_appointment_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog  modal-dialog-centered">
      <div class="modal-content">

        <form action="<?php echo e(url ('reschedule_appointment')); ?> " method="POST">
            <?php echo csrf_field(); ?>
            <?php echo e(csrf_field()); ?>

            <div class="modal-header ">
              <h5 class="modal-title" id="exampleModalLabel" class="text-center"> Reschedule</h5>
              <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
            </div>
              <div class="modal-body p-5">
                <div class="bg-danger text-white text-center mt-2 shadow-sm invalid_date_warning">
                    <div class="">
                      <div class="d-flex justify-content-center">
                        <div class="mt-1">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-exclamation-triangle" viewBox="0 0 16 16">
                            <path d="M7.938 2.016A.13.13 0 0 1 8.002 2a.13.13 0 0 1 .063.016.146.146 0 0 1 .054.057l6.857 11.667c.036.06.035.124.002.183a.163.163 0 0 1-.054.06.116.116 0 0 1-.066.017H1.146a.115.115 0 0 1-.066-.017.163.163 0 0 1-.054-.06.176.176 0 0 1 .002-.183L7.884 2.073a.147.147 0 0 1 .054-.057zm1.044-.45a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566z"/>
                            <path d="M7.002 12a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 5.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995z"/>
                          </svg> 
                        </div>
                        <div class=" ml-4">
                                 Invalid Date!
                        </div>
                      </div>
                   
                    </div>
                </div>
                <div class="bg-warning text-dark text-center mt-2 shadow-sm warning_date_warning">
                  <div class="">
                    <div class="d-flex justify-content-center">
                      <div class="mt-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-exclamation-triangle" viewBox="0 0 16 16">
                          <path d="M7.938 2.016A.13.13 0 0 1 8.002 2a.13.13 0 0 1 .063.016.146.146 0 0 1 .054.057l6.857 11.667c.036.06.035.124.002.183a.163.163 0 0 1-.054.06.116.116 0 0 1-.066.017H1.146a.115.115 0 0 1-.066-.017.163.163 0 0 1-.054-.06.176.176 0 0 1 .002-.183L7.884 2.073a.147.147 0 0 1 .054-.057zm1.044-.45a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566z"/>
                          <path d="M7.002 12a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 5.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995z"/>
                        </svg> 
                      </div>
                      <div class=" ml-4">
                               Same Date is selected!
                      </div>
                    </div>
                 
                  </div>
              </div>
                  <label for="" class="" > Pick a Date</label>
           
                <input type="text" id="appointment_id" name="appointment_id" hidden>
                <input type="text" id="service_id" name="service_id" hidden>
                <input type="text" id="new_appointment_date" name="new_appointment_date" hidden>
                <input type="text" id="old_appointment_date" name="old_appointment_date" hidden>
                


                <div class="form-group">
                  <input type="date" id="datepicker" name="datepicker" class="form-control shadow-sm rounded" >
                    
                  
                    <div class="container-fluid mt-5 rounded">
                      <div class="card text-white text-center bg-warning shadow rounded" style="height: 90px">
                          <div class="card-body">
                          <h5 class="card-title text-dark h-5">Available Slot</h5>
                          <input type="text" class="text-dark" id="available_slot_reschedule" name="available_slot_reschedule" hidden>
                          <b><p class="text-dark h5" id="available_slot_reschedule_text" name="available_slot_reschedule_text"></p></b>
                          </div>
                      </div>
                      
                  </div>
              </div>
              
            </div>
            <div class="modal-footer">
            
              <button type="submit" class="btn btn-primary reschedule_btn btn-sm w-25">Edit</button>
              <button type="button" class="btn btn-secondary btn-sm w-25" data-dismiss="modal">No</button>
            </div>
         </form>

      </div>
    </div>
  </div>

     <!-- approve modal -->

<div class="modal fade" id="approve_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">

        <form action="<?php echo e(route ('admin.approve_registration')); ?> " method="POST">
            <?php echo csrf_field(); ?>
           
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"></h5>
          <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <input type="text"  id="approve_id" name="approve_id" hidden>
        
          Are you sure you want to approve this registration?
        </div>
        <div class="modal-footer">
         
          <button type="submit" class="btn btn-primary approve_btn btn-sm w-25">Yes</button>
          <button type="button" class="btn btn-secondary btn-sm w-25" data-dismiss="modal">No</button>
        </div>
         </form>

      </div>
    </div>
  </div>

  <div class="container-fluid text-center  pt-5  pb-3 p-lg-5 mt-4 mb-4 ">
      <h3 class="fw-bolder bg-dark bg-opacity-10 text-light p-4
      ">APPOINTMENTS</h3>
  </div>

  <div class="container  col-12 col-lg-9 mb-5 table-responsive mb-4" style="height:100%;">
    <div>
      <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
              <?php echo e(session('success')); ?>

              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
      <?php elseif(session('danger')): ?>
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
          <?php echo e(session('danger')); ?>

          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
      <?php endif; ?>
    
      <?php if($errors->any()): ?>
      <div class="alert alert-danger">
          <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <?php endif; ?>
    </div>
    <?php if(Auth::User()->account_type == 'admin'): ?>
        <div class="container-fluid mb-2" style="">
            <div class="row justify-content-end ">
              <form action="<?php echo e(route('appointment_pdf')); ?>" method="POST" class=" col-12 col-lg-2 text-center mb-2 mb-lg-0 p-0" target="__blank">
                <?php echo csrf_field(); ?>
                  <?php echo e(csrf_field()); ?>

                <button type="submit" class="btn w-100 btn-sm btn-primary bi bi-filetype-pdf" > Generate PDF</button>

              </form>

              <form action="<?php echo e(route('appointment_excel')); ?>" method="POST" class="col-12 col-lg-2 text-center p-0 mr-lg-2" target="__blank ">
                <?php echo csrf_field(); ?>
                <?php echo e(csrf_field()); ?>

                <button class="btn btn-sm btn-primary w-100 bi bi-file-earmark-spreadsheet ml-lg-1 " style=""> Generate Excel</button> 
              </form>
          
            </div>

        
        </div>
    <?php endif; ?>
    <div class="row">
      <div class=" col col-12 col-lg-12">
        <div class="card shadow-sm mb-5" style="">
          <div class=" card-header text-center p-3 font-weight-bold bg-semi-grey">
            Records
          </div>
          <div class="card-body table-responsive w-100" >
                <table class="table table-hover table-striped " id="appointment_table" >
                  <thead class="">
                      <tr class="">
                        <th scope="col" class="text-center">Email</th>
                        <th scope="col" class="text-center">Services</th>
                        <th scope="col" class="text-center">Category</th>
                        <th scope="col" class="text-center">Appoitnment Date</th>
                        <th scope="col" class="text-center">Status</th>
                        <?php if(Auth::User()->account_type == 'admin'): ?>
                        <th scope="col" class="text-center">Action</th>
                        <?php endif; ?>
                      </tr>
                  </thead>
                  <tbody>
                      <?php $__currentLoopData = $appointments_admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center ">
                          <td><?php echo e($data->email); ?></td>
                          <td><?php echo e($data->appointment_services); ?></td>
                          <td><?php echo e($data->appointment_vaccine_category); ?>

                              <?php if($data->appointment_dose != null): ?>
                                <?php if($data->appointment_dose == "1"): ?>
                                     , 1st Dose
                                <?php elseif($data->appointment_dose == "2"): ?>
                                     , 2nd Dose
                                <?php elseif($data->appointment_dose == "3"): ?>
                                    , Booster
                                <?php else: ?>
                                , <?php echo e($data->appointment_vaccine_type); ?> 
                                <?php endif; ?>
                                 
                              <?php elseif($data->appointment_dose == null && $data->appointment_vaccine_type != null ): ?>
                                , <?php echo e($data->appointment_vaccine_type); ?>

                              <?php endif; ?>
                          </td>
                          <td><?php echo e($newDateFormat3 = \Carbon\Carbon::parse($data->appointment_date)->format('d/m/Y')); ?></td>
                          <td>
                            <?php if($data->appointment_status == "success"): ?>
                            <small class="bg-success px-1 rounded text-white">   <?php echo e($data->appointment_status); ?></small>
                            <?php elseif($data->appointment_status == "expired"): ?>
                            <small class="color-orange px-1 rounded text-white">   <?php echo e($data->appointment_status); ?></small>
                            <?php elseif($data->appointment_status == "pending"): ?>
                            <small class="bg-warning px-1 rounded text-white">   <?php echo e($data->appointment_status); ?></small>
                            <?php elseif($data->appointment_status == "canceled"): ?>
                            <small class="bg-danger  px-1 rounded text-white">   <?php echo e($data->appointment_status); ?></small>

                            <?php endif; ?>
                            <?php if(Auth::User()->account_type == 'admin'): ?>
                          </td>
                          <td scope="row" colspan=2 class="d-flex justify-content-center ">
                            <?php if($data->appointment_status == "pending"): ?> 
                                <button class="btn btn-sm p-0 btn-warning mt-2 mt-lg-0 ml-2 p-1 cancel_btn bi bi-x-circle text-white" value="<?php echo e($data->id); ?>" style="width: 80px"> Cancel</button>
                            <?php else: ?>
                            <button class="btn btn-sm  btn-danger mt-2 mt-lg-0 ml-2 delete_btn bi bi-trash3 " value="<?php echo e($data->id); ?>" style=""></button>
                            <?php endif; ?>
                            <?php endif; ?>
                          </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
          </div> 
        </div> 
     </div>    
    </div>

    <?php if(Auth::User()->account_type=='admin'): ?>
    
                   
                          
                            
                          
                            
    <?php endif; ?>
</div>



<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap4.min.js"></script>

</body>
</html>

<script>

  $(document).ready(function () {

    
    $(document).on('click', '.recheckup_btn',function (e) {
          e.preventDefault();

          $('#recheckup_modal').modal('show');
              var user_id = $(this).val();

              console.log(user_id);
              $('#user_id').val(user_id);
                    
                    $('#require_checkup').find(':radio[name=require][value="no"]').prop('checked', true);
                     
    //         $.ajax({
    //               type: "GET",
    //               url: "/admin/get_general_checkup/"+user_id,
    //               success: function (response) {
    //                   console.log(response);
    //                 //   $('#user_phoneNo').val(response.user_id.user_contactnumber);
    //                 //   $('#service').val(response.user_id.appointment_services);
    //                 //   $('#user_id').val(response.user_id.user_id);

                      
    //                 //   if(response.service.availability == "Yes"){
                    
    //                 // $('#yesandno_service').find(':radio[name=choice_service][value="Yes"]').prop('checked', true);
    //                 //   }else{
    //                 //     $('#yesandno_service').find(':radio[name=choice_service][value="No"]').prop('checked', true);

    //                 //   }
    //               }
    //           });
         


    });

    $(document).on('click', '.cancel_btn',function (e) {
        e.preventDefault();
        $("#cancel_message").hide();
          var cancel_id = $(this).val();
       
            // alert(service); 
            $('#calcel_id').val(cancel_id);
      

            
            $('#cancel_appointment_modal').modal('show');
            
            $.ajax({
                type: "GET",
                url: "/admin/cancel_appointment/"+cancel_id,
                success: function (response) {
                    // console.log(response);
                    $('#user_phoneNo').val(response.user_id.user_contactnumber);
                    $('#service').val(response.user_id.appointment_services);
                    $('#user_id').val(response.user_id.user_id);

                    
                    // $('#calcel_id').val(response.service.id)

                }
            });
          
      });

      $(document).on('click', '.reschedule',function (e) {
        $('.reschedule_btn').hide();
        e.preventDefault();
        $("#cancel_message").hide();
          var id = $(this).val();
            console.log(id);
            $('#reschedule_appointment_modal').modal('show');
            $('.invalid_date_warning').hide("0");
            $('.warning_date_warning').hide("0");
            $.ajax({
                type: "GET",
                url: "/admin/get_available_slot/"+id,
                success: function (response) {
                    console.log(response);
                    $('#appointment_id').val(response.date[0].appointment_id);
                    $('#old_appointment_date').val(response.date[0].appointment_date);
                    $('#service_id').val(response.date[0].service_id);
                    $('#datepicker').val(response.date[0].appointment_date);
                    // $('#available_slot_reschedule').val(response.date[0].appointment_availableslot);
                    // $('#available_slot_reschedule_text').text(response.date[0].appointment_availableslot);
                    $('#new_appointment_date').val(response.date[0].appointment_date);
                    $Mindate =  0;
                  if(response.today){
                    $Mindate= response.today;
                 
                  }
                  console.log(response);
            

                }
            });
          
      });

      $(document).on('change','#datepicker', function (e) {
        e.preventDefault();
        $appointmentdate = $(this).val();
        $service_id = $('#service_id').val();
        $appointment_id = $('#appointment_id').val();
        $old_appointment_date = $('#old_appointment_date').val();
        $datepicker_date = $(this).val();
        $invalid_date_warning =(document).getElementById("invalid_date_warning");
        $('.warning_date_warning').hide("0");
        $.ajax({
          type: "GET",
          url: "/admin/get_appointmentDate_reschedule/"+$appointment_id+"/"+$appointmentdate,
          success: function (response) {
            console.log(response);
            // var len = 0;
            // len = response['appointmentslot'].length;
            // var leng = 0;

          

              if(response.validDate == "yes"){
              $('.invalid_date_warning').hide("0");

                if($datepicker_date == $old_appointment_date){
                  $('.warning_date_warning').show("0");
                    $('.reschedule_btn').hide("0");
                    $('.invalid_date_warning').hide("0");

                } else{
                    $('.warning_date_warning').hide("0");
                    $('#available_slot_reschedule').val(response.slotschedule);
                    $('#available_slot_reschedule_text').text(response.slotschedule);
                    $('.reschedule_btn').show();
                }
             
              }else{
              $('#available_slot_reschedule').val("0");
              $('#available_slot_reschedule_text').text("0");
              $('.invalid_date_warning').show("0");
              $('.warning_date_warning').hide("0");
              $('.reschedule_btn').hide();

            }
            // if(response.validDate == "yes"){
            //   $('.invalid_date_warning').hide("0");
             

            //   $('.reschedule_btn').show();
            //         if (len > 0) {
            //           for(var i=0; i<1; i++){ 
            //               if(response['appointmentslot'][i].appointment_availableslot != 0){
            //                   $('#available_slot_reschedule').val(response['appointmentslot'][i].appointment_availableslot);
            //                   $('#available_slot_reschedule_text').text(response['appointmentslot'][i].appointment_availableslot);
            //                   $('#new_appointment_date').val(response['appointmentslot'][i].appointment_date);

            //                   if($datepicker_date == $old_appointment_date){
            //                       $('.warning_date_warning').show("0");
            //                       $('.reschedule_btn').hide("0");

            //                 } 
                      

            //               }else{
            //                   $('#available_slot_reschedule').val("0");
            //                   $('#available_slot_reschedule_text').text("0");
            //                   $('.reschedule_btn').hide("0");
            //                   $('.warning_date_warning').show("0");
                          

                            
            //               }
            //             }
            //         } else {
            //           leng = response['individualserviceslot'].length;
            //                 console.log("pumasok sa service table");
            //                 $service_id =  $('#service_id').val();
            //                 $('#new_appointment_date').val($datepicker_date);
                        

                          
            //                   for(var i=0; i<leng; i++){
                      
            //                       if($service_id == response['individualserviceslot'][i].id){
            //                           // console.log($service_id);
            //                           $('#available_slot_reschedule').val(response['individualserviceslot'][i].availableslot);
            //                           $('#available_slot_reschedule_text').text(response['individualserviceslot'][i].availableslot);
                                        
            //                       }
                                
            //                     }
                                           

            //         }
                  
            // }else{
            //   $('#available_slot_reschedule').val("0");
            //   $('#available_slot_reschedule_text').text("0");
            //   $('.invalid_date_warning').show("0");
            //   $('.warning_date_warning').hide("0");
            //   $('.reschedule_btn').hide();

            // }
          }
        });

        
      });
      
    $(document).on('click', '.delete_btn',function (e) {
        e.preventDefault();
          var del_id = $(this).val();
            // alert(service); 
            $('#delete_id').val(del_id);
            $('#delete_appointment_modal').modal('show');
        
      });

      $('#message_select').on('change','', function (e) {
        e.preventDefault();
        $("#cancel_message").hide();
        
        if($(this).val() == "default_message"){
        //  $('#message').val("the "+ $('#service').val() +" Appointment has been cancled!");
         
          console.log("default");

        }else if($(this).val() == "add_message"){
         $('#message').val("add");
         $("#cancel_message").show();
          
        }
        
      });


      $(document).ready( function () {
            $('#appointment_table').DataTable();
        });
        $(document).ready( function () {
     
        $('#re-checkup_table').DataTable();

      });
  });

</script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\AppointmentSystem\resources\views/appointment.blade.php ENDPATH**/ ?>