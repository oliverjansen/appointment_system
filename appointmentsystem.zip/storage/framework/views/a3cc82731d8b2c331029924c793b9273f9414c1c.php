<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
       <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
        
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <title>Document</title>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/customize.css')); ?>" >
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap4.min.css">
      </head>
    <body>
    
      
      <div class="container-fluid text-center  pt-5  pb-3 p-lg-5 mt-4 mb-4 ">
        <h3 class="fw-bolder bg-dark bg-opacity-10 text-light p-4">APPOINTMENT HISTORY</h3>
    </div>
      
      <div class="container-fluid col-12 col-lg-8" style="height:100%;">
          <div>
            <?php if(session('success')): ?>
               <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
               </div>
            <?php elseif(session('danger')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('danger')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
           </div>
            <?php endif; ?>
          </div> 
          
            <div class="container-fluid shadow mb-5" style="">
                 <div class="card-body col-12 table-responsive ">
                    <table class="table table-hover w-100" id="history_table_data" >
                    
                      <thead>
                          <tr class="text-center">
                            <th class="text-center">Service</th>
                            <th scope="col" class="text-center"> Category</th>
                            <th scope="col" class="text-center">Vaccine</th>
                            <th scope="col" class="text-center">Apointment Date</th>
                            <th scope="col" class="text-center">Status</th>
                      
                          </tr>
                      </thead>
                      <tbody>
                  
                          
                                  <?php $__currentLoopData = $appointmentss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="text-center ">
                                    <td ><?php echo e($value->appointment_services); ?></td>
                                    <td ><?php echo e($value->appointment_vaccine_category); ?></td>
                                  
                                      <?php if($value->appointment_dose !== null): ?>
                                         
                                      <?php endif; ?>
                                    
                                    <td >
                                      <?php if($value->appointment_dose !== null): ?>
                                         <?php if($value->appointment_dose == "1"): ?>
                                          1st dose,
                                          <?php elseif($value->appointment_dose == "2"): ?>
                                          2nd dose,
                                          <?php elseif($value->appointment_dose == "3"): ?>
                                          Booster,
                                           <?php endif; ?>
                                      <?php endif; ?>

                                      <?php echo e($value->appointment_vaccine_type); ?></td>
                                    <td ><?php echo e($value->appointment_date); ?></td>
                                    <td >
                                      <?php if($value->appointment_status == "success"): ?>
                                      <small class="bg-success p-1 rounded text-white">   <?php echo e($value->appointment_status); ?></small>
                                      <?php elseif($value->appointment_status == "expired"): ?>
                                      <small class="color-orange p-1 rounded text-white">   <?php echo e($value->appointment_status); ?></small>
                                      <?php elseif($value->appointment_status == "pending"): ?>
                                      <small class="bg-warning p-1 rounded text-white">   <?php echo e($value->appointment_status); ?></small>
                                      <?php elseif($value->appointment_status == "canceled"): ?>
                                      <small class="bg-danger p-1 rounded text-white">   <?php echo e($value->appointment_status); ?></small>

                                      <?php endif; ?>
                                    
                                    </td>
                                    </tr>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                      </tbody>
              </table> 
            </div>
            
         
          </div>
      </div>
    
    
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.js"></script>

<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap4.min.js"></script>
  </body>
    </html>
    
    
    
    <script>
        $(document).ready(function () {
          // var id = null;
          //   $(document).on('change','#sortby_history',function(e){
          //     e.preventDefault();
             
          //     id = $(this).val();
          //    console.log(id);
          //    var_dump():
          //     $.ajax({
          //         type: "GET",
          //         url: "/history/"+id,
          //         success: function (response) {
          //             // console.log(response);  
          //             // console.log(response.vaccine);
          //             // $('#available_slot').val(response.pediatic);
          //             // $('#availableslot').text(response.pediatic);
          //         }
          //     });
          //   });

          
        $(document).ready( function () {
            $('#history_table_data').DataTable();
        });
  });
    </script>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\AppointmentSystem\resources\views/history.blade.php ENDPATH**/ ?>