

        <html>
            <head>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />


                <title>Detail</title>
            </head>
            <style>
                @page { margin:0; }
                body {
                padding: 45px;
                }
                #tbDetail {
                border-style: solid;
                border-color: #776b6b;
                border-width: 0.7px;
                border-collapse: collapse;
                line-height: 16px;
                }
                #tbDetail td {
                border-style: solid;
                border-color: #776b6b;
                border-width: 0.7px;
                padding: 2px;
                }
                #tbDetail .detail-data td {
                border-style: none solid dotted none;
                }
                #tbDetail tr td span {
                display: inline-block;
                text-align: center;
                }
                .bt-1{
                border-top: 1px solid #776b6b;
                }
                .br-1 {
                border-right: 1px solid #776b6b;
                }
                .bb-1 {
                border-bottom: 1px solid #776b6b;
                }
                .text-center {
                  text-align: center;
                }

                .margin-bottom{
                  margin-bottom: 2%;
                }

                .color-orange{
                    background-color: #FF5733;
                }

            </style>
            <body>
      
              <div class="text-center m-auto">
        
                <div class=""><b>Dapitan Health Center</b></div>
                <div>  <small>Appointment Records</small></div>
              
              </div>
              <p> </p>
        
                <div class="detail" style="width:100%">
                    <table id="tbDetail" cellpadding="0" cellspacing="0" width="100%" style="font-size: 11.5px">
                        <thead>
                            <tr class="detail-header">
                                <td class="br-1 bb-1 bt-1 text-center" style="width:10%">Email</td>
                                <td class="br-1 bb-1 bt-1 text-center" style="width:10%">Services</td>
                                <td class="br-1 bb-1 bt-1 text-center" style="width:35%">Category</td>
                                <td class="br-1 bb-1 bt-1 text-center" style="width:20%">Appointment Date</td>
                                <td class="br-1 bb-1 bt-1 text-center" style="width:10%">Status</td>
                            </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $appointments_admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="detail-data text-center">
                                    <td>&#160;<?php echo e($data->email); ?></td>
                                    <td>&#160;<?php echo e($data->appointment_services); ?></td>
                                    <td>&#160;<?php echo e($data->appointment_vaccine_category); ?>

                                      <?php if($data->appointment_dose != null): ?>
                                        <?php if($data->appointment_dose == "1"): ?>
                                             , 1st Dose
                                        <?php elseif($data->appointment_dose == "2"): ?>
                                             , 2nd Dose
                                        <?php elseif($data->appointment_dose == "3"): ?>
                                            , Booster
                                        <?php else: ?>
                                        , <?php echo e($data->appointment_vaccine_type); ?> 
                                        <?php endif; ?>
                                         
                                      <?php elseif($data->appointment_dose == null && $data->appointment_vaccine_type != null ): ?>
                                        , <?php echo e($data->appointment_vaccine_type); ?>

                                      <?php endif; ?></td>
                                    <td>&#160;<?php echo e($newDateFormat3 = \Carbon\Carbon::parse($data->appointment_date)->format('d/m/Y')); ?></td>
                                    <td>&#160; <?php if($data->appointment_status == "success"): ?>
                                      <small class="bg-success px-1 rounded text-white">   <?php echo e($data->appointment_status); ?></small>
                                      <?php elseif($data->appointment_status == "expired"): ?>
                                      <small class="color-orange px-1 rounded text-white">   <?php echo e($data->appointment_status); ?></small>
                                      <?php elseif($data->appointment_status == "pending"): ?>
                                      <small class="bg-warning px-1 rounded text-white">   <?php echo e($data->appointment_status); ?></small>
                                      <?php elseif($data->appointment_status == "canceled"): ?>
                                      <small class="bg-danger  px-1 rounded text-white">   <?php echo e($data->appointment_status); ?></small>
          
                                      <?php endif; ?></td>
                                 
                                </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </body>
        </html>

<?php /**PATH C:\xampp\htdocs\AppointmentSystem\resources\views/pdf/appointment_pdf.blade.php ENDPATH**/ ?>