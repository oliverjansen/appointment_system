<h1>Forget Password Email</h1>

<p>{<?php echo $body; ?>}</p>
<br>
<a href="<?php echo e($action_link); ?>"> Reset Password</a><?php /**PATH C:\xampp\htdocs\AppointmentSystem\resources\views/email-forgot.blade.php ENDPATH**/ ?>