<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
        
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
        
        
        
        
        
        <title>DapitanHealthCenter</title>
        
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/index.css')); ?>" >
    </head>

    <style>
        @media only screen and (min-width: 601px) {
        div.example {
            font-size: 80px;
        }
        }

        /* If the screen size is 600px or less, set the font-size of <div> to 30px */
        @media only screen and (max-width: 600px) {
       
            .sm-text-center{
                text-align: center;
            }
       
        }

        #map {
        height: 400px;
        /* The height is 400 pixels */
        width: 100%;
        /* The width is the width of the web page */
        }

        .bg-sky-white{
            background-color: #F0F0F0  ;
            border-radius: 20px;
        }
            </style>
    <body >
        <header>
            <nav>
                <div id="logo">
                    <img class="logo" src=""/>
                </div>
            </nav> 
            <section class="banner">
                <div class="container">
                    <p class="h1">Welcome!</p>
                    <p id="" class="text-white h4 mb-4"> Dapitan Health Center Online Appointment</p>
                    <?php if(Route::has('login')): ?>
                
                        <?php if(auth()->guard()->check()): ?>
                            <button class="submit tow"  onclick="window.location='<?php echo e(route('afterlogin')); ?>'" type="button">Dashboard</button>

                            
                        <?php else: ?>
                          
                         <button class="submit tow" onclick="window.location='<?php echo e(url("/login")); ?>'" type="submit">Schedule Now   >></button>
                         <?php endif; ?>

                    <?php endif; ?>
                    
                </div>
            </section>
        </header>

        
        <section class="container-fluid " class="">

            <div class=" col-12 col-lg-10 mx-lg-auto bg-sky-white p-5" style="margin-top: 100px;">
                <div class="mb-3 sm-text-center " style="border-bottom:5px solid black;"> <h2 class="font-weight-bold">ANNOUNCEMENT</h2></div>
                <div class=" rounded p-2 overflow-auto" style="height: 300px">
              
                    <?php if($announcement->isEmpty()): ?>
                        <div>
                            <label class="btn-sm btn-danger  mt-5 col-12 text-center">No Announcement Yet!</label> 

                    
                        </div>
                
                    <?php endif; ?>
           
                    <?php $__currentLoopData = $announcement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="">
                        <div class="card mb-3 col col-12 shadow-sm " style="margin-left: auto; margin-right:auto; border-left:10px solid green;">
                            <div class="card-header border-dark">
                                <div class="row">
                                    <div class="col col-12 col-lg-9">
                                    <b>Publish Date : </b><?php echo e($value->publish_date); ?>

                                    </div>
                                
                                </div>
                            </div>
                            <div class="card-body text-dark ">
                                <h5 class="card-title font-weight-bold">Title: <?php echo e($value->title); ?></h5>
                                <p class="card-text "><?php echo e($value->body); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </div>
            </div>
            <div class=" col-12 col-lg-10 mx-lg-auto bg-sky-white p-5 mt-5" style="margin-top: 0px;">
                <div class="mb-3 sm-text-center" style="border-bottom:5px solid black;"> <h2 class="font-weight-bold">SERVICES</h2></div>
                <div class=" rounded pt-5 overflow-auto" style="height: 300px">

                        

                        <?php if($vaccine->isEmpty()): ?>
                        <ul>
                            <li class="btn-sm btn-danger  col-12 text-center mt-5">No Available Vaccine!</li>

                        </ul>
                        <?php else: ?>
                            <h5 class="font-weight-bold  mb-3 border-bottom border-dark p-1 text-center">Vaccine</h5>

                            <?php if($pediatric->isNotEmpty()): ?>
                                <label for="" class="font-weight-bold p-2" style="border-left: solid 5px green;">Pediatric Vaccination</label>
                                <?php $__currentLoopData = $pediatric; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="pl-5"><?php echo e($value->vaccine_type); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                                
                            <?php if($covid->isNotEmpty()): ?>
                                <label for="" class="font-weight-bold p-2" style="border-left: solid 5px green;">Covid</label>
                                <?php $__currentLoopData = $covid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="pl-5">
                                    <?php if($value->dose == "1"): ?>
                                    1st dose
                                    <?php elseif($value->dose == "2"): ?>
                                    2nd dose
                                    <?php elseif($value->dose == "3"): ?>
                                    Booster
                                    <?php endif; ?>
                            - <?php echo e($value->vaccine_type); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                    
                            <?php if($other_vaccine->isNotEmpty()): ?>

                                <label for="" class="font-weight-bold p-2" style="border-left: solid 5px green;">Others</label>
                                <?php $__currentLoopData = $other_vaccine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="pl-5"><?php echo e($value->vaccine_type); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endif; ?>
                     

                        <?php endif; ?>  
                     
                   

                    <?php if($medicine->isNotEmpty()): ?>
                        <h5 class="font-weight-bold mb-3 mt-3 border-bottom border-dark p-1 text-center"> Free Medicine</h5>
                        <?php $__currentLoopData = $medicine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                        <li class="pl-5"><?php echo e($value->other_services); ?></li>
                        
                    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                        
                 

                    <?php if($checkup->isNotEmpty()): ?>
                        <h5 class="font-weight-bold  mt-3 border-bottom mb-3 border-dark p-1 text-center">Check Up</h5>
                        <?php $__currentLoopData = $checkup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="pl-5"><?php echo e($value->other_services); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                        
                        <?php if($sevices->count()>2): ?>
                        <h5 class="font-weight-bold mb-3 border-bottom border-dark p-2 mt-5 ">Other Services </h5>
                            <?php $__currentLoopData = $sevices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul>                    
                                <li class="list-group-item"><?php echo e($value->service); ?></li>

                            </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                       <?php endif; ?>
                
                </div>
            </div>
            <div class="col-12 col-lg-10 mx-lg-auto bg-sky-white p-5 mt-5" style="margin-top: 100px; margin-bottom:70px">
                <div class="  sm-text-center" style="border-bottom:5px solid black ;p-2"> <h2 class="font-weight-bold">ABOUT US</h2></div>

                <p class="text-justify mt-4 ">
                    The Dapitan Health Center is a medical center located in the Metropolitan Manila area. The Dapitan Health Center is conveniently located next to Barangay 520, the Dapitan Public Library, and the Zone 51 Hall.To better serve the public citizens, we offer medical care. The following are Vaccine, Free Medicine, Checkup and more.
                </p>
                <p class="mt-4 sm-text-center"  style=" ">
                   <b class="mb-5"> Contact# : +63 2 741 2078</b>
                </p >
            </div>
            <!--- FIRST ROW --->
            
        

            
        </section>
      



        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> 
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        
     
    </body>



    </html>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\AppointmentSystem\resources\views/index.blade.php ENDPATH**/ ?>