<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Announcement extends Controller
{
    //
}
